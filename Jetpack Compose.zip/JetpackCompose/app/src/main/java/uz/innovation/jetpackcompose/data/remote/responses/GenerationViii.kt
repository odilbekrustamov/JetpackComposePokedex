package uz.innovation.jetpackcompose.data.remote.responses

data class GenerationViii(
    val icons: IconsX
)
package uz.innovation.jetpackcompose.data.remote.responses

data class GenerationVii(
    val icons: Icons,
    val ultra-sun-ultra-moon: UltraSunUltraMoon
)
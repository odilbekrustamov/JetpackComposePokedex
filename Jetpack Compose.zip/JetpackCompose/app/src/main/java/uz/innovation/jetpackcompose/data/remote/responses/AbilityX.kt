package uz.innovation.jetpackcompose.data.remote.responses

data class AbilityX(
    val name: String,
    val url: String
)
package uz.innovation.jetpackcompose.data.remote.responses

data class GenerationV(
    val black-white: BlackWhite
)
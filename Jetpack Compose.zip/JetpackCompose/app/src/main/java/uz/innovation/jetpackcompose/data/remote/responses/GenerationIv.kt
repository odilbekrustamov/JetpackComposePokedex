package uz.innovation.jetpackcompose.data.remote.responses

data class GenerationIv(
    val diamond-pearl: DiamondPearl,
    val heartgold-soulsilver: HeartgoldSoulsilver,
    val platinum: Platinum
)
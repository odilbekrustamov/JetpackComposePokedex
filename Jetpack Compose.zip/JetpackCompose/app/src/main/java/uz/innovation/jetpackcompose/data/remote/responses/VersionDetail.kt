package uz.innovation.jetpackcompose.data.remote.responses

data class VersionDetail(
    val rarity: Int,
    val version: Version
)
package uz.innovation.jetpackcompose.data.remote.responses

data class TypeX(
    val name: String,
    val url: String
)
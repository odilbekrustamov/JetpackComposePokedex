package uz.innovation.jetpackcompose.data.remote.responses

data class GenerationI(
    val red-blue: RedBlue,
    val yellow: Yellow
)
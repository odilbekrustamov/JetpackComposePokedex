package uz.innovation.jetpackcompose.data.remote.responses

data class OfficialArtwork(
    val front_default: String,
    val front_shiny: String
)
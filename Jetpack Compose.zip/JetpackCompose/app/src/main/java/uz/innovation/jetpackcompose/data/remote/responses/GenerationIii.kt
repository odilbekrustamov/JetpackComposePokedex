package uz.innovation.jetpackcompose.data.remote.responses

data class GenerationIii(
    val emerald: Emerald,
    val firered-leafgreen: FireredLeafgreen,
    val ruby-sapphire: RubySapphire
)
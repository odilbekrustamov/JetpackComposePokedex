package uz.innovation.jetpackcompose.data.remote.responses

data class Result(
    val name: String,
    val url: String
)
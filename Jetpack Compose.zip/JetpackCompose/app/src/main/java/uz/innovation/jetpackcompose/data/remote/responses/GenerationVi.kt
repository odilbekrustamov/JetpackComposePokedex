package uz.innovation.jetpackcompose.data.remote.responses

data class GenerationVi(
    val omegaruby-alphasapphire: OmegarubyAlphasapphire,
    val x-y: XY
)
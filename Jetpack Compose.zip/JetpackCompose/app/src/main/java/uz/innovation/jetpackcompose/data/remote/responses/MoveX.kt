package uz.innovation.jetpackcompose.data.remote.responses

data class MoveX(
    val name: String,
    val url: String
)